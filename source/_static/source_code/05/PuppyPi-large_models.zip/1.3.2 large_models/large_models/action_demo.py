#!/usr/bin/env python3
# encoding: utf-8
# @Author: Aiden
# @Date: 2024/11/05

def forward():
    print('forward')

def back():
    print('back')

def turn_left():
    print('turn_left')

def turn_right():
    print('turn_right')

def track(color):
    print(color)

