#!/usr/bin/env python3
# encoding: utf-8
# @Author: Aiden
# @Date: 2025/02/28
import cv2
from config import *
from speech import speech

client = speech.OpenAIAPI(api_key, base_url)

image = cv2.imread('./resources/pictures/test_image_understand.jpeg')
# 此处以qwen-vl-max-latest例，可按需更换模型名称。模型列表：https://help.aliyun.com/zh/model-studio/getting-started/models
print(client.vllm('图片里内容是什么?', image, prompt='', model='qwen-vl-max-latest'))

