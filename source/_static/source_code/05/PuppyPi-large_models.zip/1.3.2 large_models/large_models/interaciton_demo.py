#!/usr/bin/env python3
# encoding: utf-8
# @Author: Aiden
# @Date: 2025/03/05
import os
import time
from config import *
from speech import awake
from speech import speech

wakeup_audio_path = './resources/audio/wakeup.wav'
start_audio_path = './resources/audio/start_audio.wav'
no_voice_audio_path = './resources/audio/no_voice.wav'

ksw = awake.WonderEchoPro('/dev/ttyUSB0')

asr = speech.RealTimeASR(channel=1)
tts = speech.RealTimeTTS()
client = speech.OpenAIAPI(api_key, base_url)

try:
    os.system('pinctrl FAN_PWM op dh')
except:
    pass

speech.set_volume(100)
speech.play_audio(start_audio_path)
print('start...')

def main():
    ksw.start()
    while True:
        try:
            if ksw.detect(): # 检测到唤醒词
                speech.play_audio(wakeup_audio_path)  # 唤醒播放
                asr_result = asr.asr() # 开启录音识别
                print('asr_result:', asr_result)
                if asr_result:
                    # 将识别结果传给智能体让他来回答
                    response = client.llm(asr_result)
                    print('llm response:', response)
                    tts.tts(response)
                else:
                    speech.play_audio(no_voice_audio_path)
            else:
                time.sleep(0.02)
            ksw.start()
        except KeyboardInterrupt:
            ksw.exit() 
            try:
                os.system('pinctrl FAN_PWM a0')
            except:
                pass
            break
        except BaseException as e:
            print(e)

if __name__ == '__main__':
    main()
