#!/usr/bin/env python3
# encoding: utf-8
# @Author: Aiden
# @Date: 2025/02/28
from config import *
from speech import speech

client = speech.OpenAIAPI(api_key, base_url)

# print(client.llm_origin('以科技改变生活写一段50字的中文文案', prompt='', model='qwen-max'))
print(client.llm('以科技改变生活写一段50字的中文文案', prompt='', model='qwen-max')) # 此处以qwen-max为例，可按需更换模型名称。模型列表：https://help.aliyun.com/zh/model-studio/getting-started/models
