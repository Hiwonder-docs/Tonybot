import dashscope

api_key = ''
base_url = 'https://dashscope.aliyuncs.com/compatible-mode/v1'
dashscope.api_key = api_key
